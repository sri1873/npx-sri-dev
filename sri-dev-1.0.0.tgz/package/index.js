#!/usr/bin/env node

const reset = "\x1b[0m";
const bold = "\x1b[1m";
const cyan = "\x1b[36m";
const gray = "\x1b[90m";

console.log(`
${cyan}${bold}
╭────────────────────────────────────────────────────╮
│                                                    │
│  SRI KUMAR                                         │
│  SOFTWARE ENGINEER                                 │
│                                                    │
╰────────────────────────────────────────────────────╯
${reset}

${bold}Backend${reset} • ${bold}Full Stack${reset} • ${bold}Cloud${reset}

${gray}Java • Spring Boot • AWS • Docker • PostgreSQL${reset}

${bold}GitHub${reset}    https://github.com/YOUR_USERNAME
${bold}LinkedIn${reset}  https://linkedin.com/in/YOUR_USERNAME

${gray}Open to Software Engineering opportunities.${reset}
`);